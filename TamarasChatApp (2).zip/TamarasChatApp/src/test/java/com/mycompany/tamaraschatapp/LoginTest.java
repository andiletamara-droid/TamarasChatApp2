/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tamaraschatapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Login class.
 *
 * @author Student
 */
public class LoginTest {

    /**
     * Creates a user containing valid registration details.
     *
     * @return a Login object with valid information
     */
    private Login createValidUser() {

        return new Login(
                "John",
                "Doe",
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976"
        );
    }

    @Test
    public void validUsernameShouldBeAccepted() {

        Login user = createValidUser();

        assertTrue(user.checkUserName());
    }

    @Test
    public void invalidUsernameShouldBeRejected() {

        Login user = new Login(
                "John",
                "Doe",
                "kyle!!!!",
                "Ch&&sec@ke99!",
                "+27838968976"
        );

        assertFalse(user.checkUserName());
    }

    @Test
    public void validPasswordShouldBeAccepted() {

        Login user = createValidUser();

        assertTrue(user.checkPasswordComplexity());
    }

    @Test
    public void invalidPasswordShouldBeRejected() {

        Login user = new Login(
                "John",
                "Doe",
                "kyl_1",
                "password",
                "+27838968976"
        );

        assertFalse(user.checkPasswordComplexity());
    }

    @Test
    public void validCellNumberShouldBeAccepted() {

        Login user = createValidUser();

        assertTrue(user.checkCellPhoneNumber());
    }

    @Test
    public void invalidCellNumberShouldBeRejected() {

        Login user = new Login(
                "John",
                "Doe",
                "kyl_1",
                "Ch&&sec@ke99!",
                "08966553"
        );

        assertFalse(user.checkCellPhoneNumber());
    }

    @Test
    public void validDetailsShouldRegisterSuccessfully() {

        Login user = createValidUser();

        assertEquals(
                "User successfully registered.",
                user.registerUser()
        );
    }

    @Test
    public void invalidUsernameShouldReturnCorrectMessage() {

        Login user = new Login(
                "John",
                "Doe",
                "kyle!!!!",
                "Ch&&sec@ke99!",
                "+27838968976"
        );

        assertEquals(
                "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.",
                user.registerUser()
        );
    }

    @Test
    public void invalidPasswordShouldReturnCorrectMessage() {

        Login user = new Login(
                "John",
                "Doe",
                "kyl_1",
                "password",
                "+27838968976"
        );

        assertEquals(
                "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
                user.registerUser()
        );
    }

    @Test
    public void invalidCellNumberShouldReturnCorrectMessage() {

        Login user = new Login(
                "John",
                "Doe",
                "kyl_1",
                "Ch&&sec@ke99!",
                "08966553"
        );

        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain an international code; please correct the number and try again.",
                user.registerUser()
        );
    }

    @Test
    public void correctCredentialsShouldAllowLogin() {

        Login user = createValidUser();

        user.registerUser();

        assertTrue(
                user.loginUser(
                        "kyl_1",
                        "Ch&&sec@ke99!"
                )
        );
    }

    @Test
    public void incorrectCredentialsShouldRejectLogin() {

        Login user = createValidUser();

        user.registerUser();

        assertFalse(
                user.loginUser(
                        "wrong_user",
                        "wrongPassword"
                )
        );
    }

    @Test
    public void successfulLoginShouldReturnWelcomeMessage() {

        Login user = createValidUser();

        user.registerUser();

        assertEquals(
                "Welcome John Doe, it is great to see you again.",
                user.returnLoginStatus(
                        "kyl_1",
                        "Ch&&sec@ke99!"
                )
        );
    }

    @Test
    public void failedLoginShouldReturnErrorMessage() {

        Login user = createValidUser();

        user.registerUser();

        assertEquals(
                "Username or password incorrect, please try again.",
                user.returnLoginStatus(
                        "wrong_user",
                        "wrongPassword"
                )
        );
    }
}