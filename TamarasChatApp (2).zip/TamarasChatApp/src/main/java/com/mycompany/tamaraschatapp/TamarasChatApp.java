package com.mycompany.tamaraschatapp;


import java.util.Scanner;

/**
 * Main class for the Chat App.
 */
public class TamarasChatApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("=================================");
        System.out.println("           TAMARA'S CHAT APP");
        System.out.println("       User Registration");
        System.out.println("=================================");

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine().trim();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine().trim();

        Login userAccount;

        /*
         * Keep asking for registration details until
         * all validation requirements have been satisfied.
         */
        while (true) {

            System.out.println("\n---------------------------------");
            System.out.println("Enter Registration Details");
            System.out.println("---------------------------------");

            System.out.print("Create a username: ");
            String username = input.nextLine().trim();

            System.out.print("Create a password: ");
            String password = input.nextLine();

            System.out.print("Enter your cell phone number: ");
            String cellNumber = input.nextLine().trim();

            userAccount = new Login(
                    firstName,
                    lastName,
                    username,
                    password,
                    cellNumber
            );

            String registrationMessage = userAccount.registerUser();

            System.out.println("\nRegistration Result:");
            System.out.println(registrationMessage);

            if (registrationMessage.equals("User successfully registered.")) {
                break;
            }

            System.out.println("\nPlease enter your registration details again.");
        }

        /*
         * Login section.
         * The loop continues until the correct credentials
         * are supplied.
         */
        System.out.println("\n=================================");
        System.out.println("             LOGIN");
        System.out.println("=================================");

        boolean loggedIn = false;

        while (!loggedIn) {

            System.out.print("Username: ");
            String loginUsername = input.nextLine().trim();

            System.out.print("Password: ");
            String loginPassword = input.nextLine();

            loggedIn = userAccount.loginUser(
                    loginUsername,
                    loginPassword
            );

            if (loggedIn) {

                System.out.println("\n"
                        + userAccount.returnLoginStatus(
                                loginUsername,
                                loginPassword
                        ));

            } else {

                System.out.println("\nUsername or password incorrect, please try again.");
                System.out.println("Please enter your login details again.\n");
            }
        }

        System.out.println("\n=================================");
        System.out.println("       Welcome to Tamara's Chat App!");
        System.out.println("=================================");

        input.close();
    }
}