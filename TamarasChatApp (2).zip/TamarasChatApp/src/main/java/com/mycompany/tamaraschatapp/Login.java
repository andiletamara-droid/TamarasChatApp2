/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tamaraschatapp;

import java.util.regex.Pattern;

/**
 * Handles user registration and login validation.
 *
 * @author Student
 */
public class Login {

    private final String username;
    private final String password;
    private final String cellPhoneNumber;
    private final String firstName;
    private final String lastName;

    private boolean accountRegistered;

    /**
     * Creates a Login object containing the user's registration details.
     *
     * @param firstName user's first name
     * @param lastName user's last name
     * @param username user's chosen username
     * @param password user's chosen password
     * @param cellPhoneNumber user's cellphone number
     */
    public Login(String firstName, String lastName, String username,
                 String password, String cellPhoneNumber) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;

        accountRegistered = false;
    }

    /**
     * Checks whether the username meets the required format.
     *
     * The username must contain an underscore and may not
     * be longer than five characters.
     *
     * @return true if the username is valid, otherwise false
     */
    public Boolean checkUserName() {

        if (username == null || username.isEmpty()) {
            return false;
        }

        return username.contains("_") && username.length() <= 5;
    }

    /**
     * Checks whether the password meets the required
     * complexity rules.
     *
     * The password must contain:
     * - At least eight characters
     * - A capital letter
     * - A number
     * - A special character
     *
     * @return true if the password is valid, otherwise false
     */
    public Boolean checkPasswordComplexity() {

        if (password == null || password.length() < 8) {
            return false;
        }

        boolean containsCapitalLetter =
                Pattern.compile("[A-Z]")
                        .matcher(password)
                        .find();

        boolean containsNumber =
                Pattern.compile("[0-9]")
                        .matcher(password)
                        .find();

        boolean containsSpecialCharacter =
                Pattern.compile("[^a-zA-Z0-9]")
                        .matcher(password)
                        .find();

        return containsCapitalLetter
                && containsNumber
                && containsSpecialCharacter;
    }

    /**
     * Checks whether the cellphone number is correctly formatted.
     *
     * The number must use the South African international format:
     * +27 followed by nine digits.
     *
     * @return true if the cellphone number is valid, otherwise false
     */
    public Boolean checkCellPhoneNumber() {

        if (cellPhoneNumber == null) {
            return false;
        }

        String phonePattern = "^\\+27\\d{9}$";

        return Pattern.matches(phonePattern, cellPhoneNumber);
    }

    /**
     * Registers the user after validating all registration details.
     *
     * @return a message explaining whether registration succeeded
     */
    public String registerUser() {

        if (!checkUserName()) {

            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity()) {

            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {

            return "Cell phone number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }

        accountRegistered = true;

        return "User successfully registered.";
    }

    /**
     * Checks whether the supplied login information matches
     * the registered user's credentials.
     *
     * @param enteredUsername username entered during login
     * @param enteredPassword password entered during login
     * @return true when the credentials are correct
     */
    public Boolean loginUser(String enteredUsername,
                             String enteredPassword) {

        if (!accountRegistered) {
            return false;
        }

        if (enteredUsername == null || enteredPassword == null) {
            return false;
        }

        return username.equals(enteredUsername)
                && password.equals(enteredPassword);
    }

    /**
     * Returns a message describing the result of the login attempt.
     *
     * @param enteredUsername username entered during login
     * @param enteredPassword password entered during login
     * @return login status message
     */
    public String returnLoginStatus(String enteredUsername,
                                    String enteredPassword) {

        if (loginUser(enteredUsername, enteredPassword)) {

            return "Welcome " + firstName + " " + lastName
                    + ", it is great to see you again.";
        }

        return "Username or password incorrect, please try again.";
    }
}